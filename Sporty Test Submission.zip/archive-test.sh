#!/usr/bin/env sh
set -eu

zip -r "Sporty Test Submission.zip" ./
