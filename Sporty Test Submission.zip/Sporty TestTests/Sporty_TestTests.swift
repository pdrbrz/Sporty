@testable import Sporty_Test
import Testing

struct Sporty_UIKit_TestTests {
    @Test func example() async throws {}
}
